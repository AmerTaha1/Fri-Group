# Data Analysis/Data Visualization Report: Bike Ride Trends and Biker Types of Ford GoBike System in 2019
## by Kirolos Samuel Azmy


## Dataset
- This document explores the Ford GoBike's trip data for public containing bike rides during whole 2019. The attributes included the trip start/end time, as well as additional measurements such as user type, start and end stations and so on
- Some columns are added for more proper analysis.
-  94K data points were removed from the analysis due to missing values in some fields, data inconsistent, or outliner issues.


## Summary of Findings
1. Bike Ride Duration Time: The origianl duration data has right skew issue - bike durations range from less than 1 minute to 1400+ minutes with mean at around 9.4 min and mean at around 13.4 min.We have to do some data transformation to make data visualization and data interpretation easiler.

2. Regarding the bike ride trends and biker types:
    1. Subscribers tend to be more regular , Weekday seems to be perfect though the duration is lower as compared to Saturday and Sunday.
    2. Winter affects a lot the revenue.
    3. Evening period in the day is the least one in terms of number of trips.
    4. Customers uses way more portion of trips during the weekend days with comparison to the subscribers.


## Key Insights for Presentation
Below are the insights for the presentation:
1) The distribution of biking durations is skewed. After log transformation and outliner removing, we may visualize and interpret data better.
2)  Peak biking period through day , season and day are shared. Biker types were analyzed.
3) The patterns/trends for bikers from prespective are shared. 
